'use client'
import { useState } from 'react'
import {
  BarChart3, Ticket, Users, DollarSign, TrendingUp,
  Search, Filter, Eye, Edit, MoreHorizontal, Plus,
  CalendarDays, MapPin, CheckCircle, XCircle, Clock
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { mockEvents, mockOrders } from '@/lib/mock-data'

const stats = [
  { label: '總銷售額', value: 'NT$ 2,450,000', icon: DollarSign, change: '+12.5%', color: 'bg-emerald-50 text-emerald-600' },
  { label: '已售票數', value: '8,432', icon: Ticket, change: '+8.2%', color: 'bg-blue-50 text-blue-600' },
  { label: '活躍用戶', value: '5,218', icon: Users, change: '+15.1%', color: 'bg-green-50 text-green-600' },
  { label: '本月活動', value: '14', icon: CalendarDays, change: '+2', color: 'bg-orange-50 text-orange-600' },
]

const recentOrders = [
  { id: 'ORD-2025-101', user: '王小明', event: '2025 台北演唱會', seats: 2, amount: 7600, status: 'paid', time: '10 分鐘前' },
  { id: 'ORD-2025-102', user: '李美玲', event: 'BLACKPINK TOUR', seats: 1, amount: 8800, status: 'paid', time: '25 分鐘前' },
  { id: 'ORD-2025-103', user: '陳志偉', event: '草東沒有派對', seats: 3, amount: 3600, status: 'pending', time: '1 小時前' },
  { id: 'ORD-2025-104', user: '張雅婷', event: '2025 台北演唱會', seats: 4, amount: 15200, status: 'paid', time: '2 小時前' },
  { id: 'ORD-2025-105', user: '林大為', event: 'Jazz in the Park', seats: 2, amount: 2400, status: 'cancelled', time: '3 小時前' },
]

function SalesChart() {
  const data = [65, 80, 55, 90, 75, 100, 85, 70, 95, 60, 88, 92]
  const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
  const max = Math.max(...data)
  return (
    <div className="flex items-end gap-1.5 h-32">
      {data.map((val, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div
            className="w-full rounded-t-md bg-emerald-400 hover:bg-emerald-600 transition-colors cursor-pointer"
            style={{ height: `${(val / max) * 100}%` }}
            title={`${months[i]}: ${val}%`}
          />
          <span className="text-[9px] text-gray-400">{months[i]}</span>
        </div>
      ))}
    </div>
  )
}

export default function AdminPage() {
  const [orderSearch, setOrderSearch] = useState('')
  const [eventSearch, setEventSearch] = useState('')

  const filteredOrders = recentOrders.filter(o =>
    !orderSearch || o.user.includes(orderSearch) || o.event.includes(orderSearch) || o.id.includes(orderSearch)
  )

  const filteredEvents = mockEvents.filter(e =>
    !eventSearch || e.title.includes(eventSearch) || e.artist.includes(eventSearch)
  )

  return (
    <div className="container mx-auto px-4 py-6 max-w-7xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">後台管理</h1>
          <p className="text-gray-400 text-sm">Echo Goo 管理系統</p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Plus className="h-4 w-4 mr-1" />
          新增活動
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map(stat => (
          <Card key={stat.label} className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-xl ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
                <Badge className="bg-green-50 text-green-600 text-xs border-0">{stat.change}</Badge>
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-400 mt-0.5">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        {/* Sales Chart */}
        <Card className="lg:col-span-2 border-0 shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-emerald-600" />
                2025 銷售趨勢
              </CardTitle>
              <Badge variant="outline" className="text-xs">月度</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <SalesChart />
          </CardContent>
        </Card>

        {/* Top Events */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-600" />
              熱門活動
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mockEvents.slice(0, 4).map((event, i) => {
              const pct = Math.round((1 - event.availableSeats / event.totalSeats) * 100)
              return (
                <div key={event.id} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 text-xs font-bold flex items-center justify-center">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{event.title}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <div className="h-1.5 flex-1 bg-gray-100 rounded-full">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-gray-400">{pct}%</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="orders">
        <TabsList className="mb-4">
          <TabsTrigger value="orders">訂單管理</TabsTrigger>
          <TabsTrigger value="events">活動管理</TabsTrigger>
          <TabsTrigger value="users">用戶管理</TabsTrigger>
        </TabsList>

        {/* Orders Tab */}
        <TabsContent value="orders">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜尋訂單、用戶、活動..."
                    className="pl-9"
                    value={orderSearch}
                    onChange={e => setOrderSearch(e.target.value)}
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-1" />篩選
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-400 border-b">
                      <th className="pb-3 pr-4 font-medium">訂單編號</th>
                      <th className="pb-3 pr-4 font-medium">用戶</th>
                      <th className="pb-3 pr-4 font-medium">活動</th>
                      <th className="pb-3 pr-4 font-medium">張數</th>
                      <th className="pb-3 pr-4 font-medium">金額</th>
                      <th className="pb-3 pr-4 font-medium">狀態</th>
                      <th className="pb-3 font-medium">時間</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredOrders.map(order => (
                      <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                        <td className="py-3 pr-4 font-mono text-xs text-gray-500">{order.id}</td>
                        <td className="py-3 pr-4 font-medium">{order.user}</td>
                        <td className="py-3 pr-4 text-gray-600 max-w-32 truncate">{order.event}</td>
                        <td className="py-3 pr-4 text-center">{order.seats}</td>
                        <td className="py-3 pr-4 font-medium">NT$ {order.amount.toLocaleString()}</td>
                        <td className="py-3 pr-4">
                          {order.status === 'paid' ? (
                            <Badge className="bg-green-50 text-green-600 border border-green-200 text-xs">
                              <CheckCircle className="h-3 w-3 mr-1" />已付款
                            </Badge>
                          ) : order.status === 'pending' ? (
                            <Badge className="bg-yellow-50 text-yellow-600 border border-yellow-200 text-xs">
                              <Clock className="h-3 w-3 mr-1" />待付款
                            </Badge>
                          ) : (
                            <Badge className="bg-red-50 text-red-600 border border-red-200 text-xs">
                              <XCircle className="h-3 w-3 mr-1" />已取消
                            </Badge>
                          )}
                        </td>
                        <td className="py-3 text-gray-400 text-xs">{order.time}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Events Tab */}
        <TabsContent value="events">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜尋活動名稱、藝人..."
                    className="pl-9"
                    value={eventSearch}
                    onChange={e => setEventSearch(e.target.value)}
                  />
                </div>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" size="sm">
                  <Plus className="h-4 w-4 mr-1" />新增
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredEvents.map(event => {
                  const soldPct = Math.round((1 - event.availableSeats / event.totalSeats) * 100)
                  return (
                    <div key={event.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <img src={event.image} alt={event.title} className="w-14 h-14 rounded-xl object-cover" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-gray-900 truncate">{event.title}</p>
                          <Badge
                            className={`text-xs shrink-0 ${
                              event.status === 'on-sale' ? 'bg-green-50 text-green-600 border border-green-200' :
                              event.status === 'sold-out' ? 'bg-gray-100 text-gray-500' :
                              'bg-blue-50 text-blue-600 border border-blue-200'
                            }`}
                          >
                            {event.status === 'on-sale' ? '銷售中' : event.status === 'sold-out' ? '已售完' : '即將開賣'}
                          </Badge>
                        </div>
                        <div className="flex gap-3 text-xs text-gray-400 mt-1">
                          <span className="flex items-center gap-0.5"><CalendarDays className="h-3 w-3" />{event.date}</span>
                          <span className="flex items-center gap-0.5"><MapPin className="h-3 w-3" />{event.venue}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1.5">
                          <div className="h-1.5 flex-1 bg-gray-100 rounded-full max-w-32">
                            <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${soldPct}%` }} />
                          </div>
                          <span className="text-xs text-gray-400">已售 {soldPct}%</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-bold text-emerald-600 text-sm">NT$ {event.priceFrom.toLocaleString()}</p>
                        <p className="text-xs text-gray-400">起</p>
                      </div>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-8 w-8">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-8 w-8">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="grid grid-cols-3 gap-4 mb-6">
                {[
                  { label: '已驗證用戶', value: '4,821', color: 'text-green-600' },
                  { label: '待驗證', value: '397', color: 'text-yellow-500' },
                  { label: '今日新增', value: '124', color: 'text-emerald-600' },
                ].map(item => (
                  <div key={item.label} className="text-center p-4 bg-gray-50 rounded-xl">
                    <p className={`text-2xl font-bold ${item.color}`}>{item.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{item.label}</p>
                  </div>
                ))}
              </div>
              <Separator className="mb-4" />
              <div className="space-y-3">
                {[
                  { name: '王小明', phone: '0912***456', verified: true, orders: 3, joined: '2025-01-15' },
                  { name: '李美玲', phone: '0928***789', verified: true, orders: 7, joined: '2025-02-08' },
                  { name: '陳志偉', phone: '0955***321', verified: false, orders: 1, joined: '2025-04-18' },
                  { name: '張雅婷', phone: '0933***654', verified: true, orders: 5, joined: '2025-03-22' },
                ].map((user, i) => (
                  <div key={i} className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                    <div className="w-9 h-9 rounded-full bg-emerald-100 flex items-center justify-center text-sm font-bold text-emerald-700">
                      {user.name[0]}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{user.name}</span>
                        {user.verified ? (
                          <Badge className="bg-green-50 text-green-600 border border-green-200 text-xs">已驗證</Badge>
                        ) : (
                          <Badge className="bg-yellow-50 text-yellow-600 border border-yellow-200 text-xs">待驗證</Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-400">{user.phone} · 加入於 {user.joined}</p>
                    </div>
                    <div className="text-right text-sm">
                      <p className="font-medium">{user.orders} 筆訂單</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
